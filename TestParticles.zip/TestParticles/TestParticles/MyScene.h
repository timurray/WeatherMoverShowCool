//
//  MyScene.h
//  TestParticles
//
//  Created by Timothy Murray on 2016-04-12.
//  Copyright © 2016 Timothy Murray. All rights reserved.
//


#import <SpriteKit/SpriteKit.h>
#import <UIKit/UIKit.h>

@interface MyScene : SKScene

@end