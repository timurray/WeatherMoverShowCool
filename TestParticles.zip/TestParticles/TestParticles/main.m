//
//  main.m
//  TestParticles
//
//  Created by Timothy Murray on 2016-04-12.
//  Copyright © 2016 Timothy Murray. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
